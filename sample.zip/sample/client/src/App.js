import React, { Component }  from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import AvailableBlood from "./compo/availableBlood/availableBlood.js"
import Contact from "./compo/contact/contact.js"
import DonateBlood from "./compo/donate/donateBlood.js"
import Home from "./compo/home/home.js"
import Register from './compo/donate/register/register.js'
import View from './compo/availableBlood/view/view.js'
import './App.css';

const App = ()=> {
  return (
    <div className="App">
      <BrowserRouter>
          <Routes>
            <Route index element={<Home/>} />
            <Route path="/availableBlood" element={<AvailableBlood/>} />
            <Route path="/contact" element={<Contact/>} />
            <Route path="/donateBlood" element={<DonateBlood/>} />
            <Route path="/donateBlood/register" element={<Register/>} />
            <Route path="/availableBlood/view/:_id" element={<View/>} />
            
        </Routes>
      </BrowserRouter>

  
      
    </div>
  );
}

export default App;
