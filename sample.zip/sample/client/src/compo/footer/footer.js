import React from 'react'
import { Link } from "react-router-dom";
import './footer.css'
export default function Footer() {
    return (
        
  
        <footer id="footer" className="text-center text-white" style={{backgroundColor: "#2c2e30"}}>
    
            <div className="containerFooter p-4 pb-0">
                <div>
                    <a style={{marginRight:"20px"}} href="#">Home</a>
                    <a style={{marginRight:"20px"}} href="#">Features</a>
                    <a style={{marginRight:"20px"}} href="#">Contact Us</a>
                </div>
                <section>
                    <p className="d-flex justify-content-center align-items-center">
                        <span className="me-3">Became A Donor</span>
                            <Link to="donateBlood">
                                <button type="button" className="btn btn-outline-light btn-rounded">
                                    Donate
                            </button>
                            </Link>
                    </p>
                </section>
      
            </div>
    

    
        <div className="text-center p-3" style={{backgroundColor: "#212529"}}>
             © 2022 Copyright:
            <a className="text-white" href="https://mdbootstrap.com/">   blood-x.com</a>
        </div>
    
  </footer>


    )
}
