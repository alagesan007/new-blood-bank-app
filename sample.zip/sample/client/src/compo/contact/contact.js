import React from 'react'
import Navbar from "../navbar/navbar.js";

export default function Contact() {
    return (
    //     <Container>
    //   <Row>
    //     <Col md={{ span: 6, offset: 3 }}>
    //       <h1>Contact Us</h1>
    //       <p>Fill out the form below to send us a message.</p>
    //       <Form>
    //         <Form.Group controlId="formBasicName">
    //           <Form.Label>Name</Form.Label>
    //           <Form.Control type="text" placeholder="Enter your name" />
    //         </Form.Group>

    //         <Form.Group controlId="formBasicEmail">
    //           <Form.Label>Email address</Form.Label>
    //           <Form.Control type="email" placeholder="Enter email" />
    //         </Form.Group>

    //         <Form.Group controlId="formBasicSubject">
    //           <Form.Label>Subject</Form.Label>
    //           <Form.Control type="text" placeholder="Enter subject" />
    //         </Form.Group>

    //         <Form.Group controlId="formBasicMessage">
    //           <Form.Label>Message</Form.Label>
    //           <Form.Control as="textarea" rows={3} placeholder="Enter your message" />
    //         </Form.Group>

    //         <Button variant="primary" type="submit">
    //           Submit
    //         </Button>
    //       </Form>
    //     </Col>
    //   </Row>
    // </Container>
    <h2>contact page</h2>
    );
}
