import React from 'react'
import "./navbar.css";
import { Link } from "react-router-dom";

export default function Navbar() {
    return (
        <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
            <h1><a className="navbar-brand" href="#">BLOOD-X</a></h1>
            <img src="https://www.pngmart.com/files/12/Save-Lives-PNG-Free-Download.png" alt="" width="40px" height="40px"/>
           
                <ul className="navbar-nav m-auto">
                {/* <Link to="/">
                        <li className="nav-item d-none d-sm-block">
                            <a className="nav-link " href="#">Home</a>
                        </li>
                    </Link> */}
                    <Link to="/availableBlood">
                        <li className="nav-item d-none d-sm-block">
                            <a className="nav-link " href="#">Available Blood</a>
                        </li>
                    </Link>
                    <Link to="/contact">
                        <li className="nav-item d-none d-sm-block">
                            <a className="nav-link " href="#">Contact us</a>
                        </li>
                    </Link> 
                    
   
                </ul>
                <Link to="/donateBlood">
                        
                    <button className="btn btn-danger btn-md">Donate Blood</button>
                        
                </Link>
             
        </nav>
    )
}
