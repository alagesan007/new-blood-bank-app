import React, { Component } from 'react'
import Navbar from "../navbar/navbar.js";
import axios from "axios";
import './available.css';
import Footer from '../footer/footer.js'
import { Link } from "react-router-dom";



export default class availableBlood extends Component {
    constructor(){
        super();
        this.state = {
            data : {},
            count:1,
            Search:"",
            Loading:true
        }
    }

    componentDidMount(){
        this.getAll();
    }
    getAll(){
        axios.get("https://excel-blood-bank-management-system.onrender.com/get")
        .then(res => {
            console.log(res.data)
            this.setState({
                data:res.data
            })
            this.setState({Loading:false})
        })
        .catch(err => {
            console.error(err); 
        })
    }
    
    
    render() {
        return (
            <>
            <Navbar/>
            <div className = "containerOuter">
                <div class="innnerContainer">
                    <br/>
                    <div class="search">
                        <form  class="form-inline">
                            <input class="form-control"onChange={(e)=>{this.setState({Search:e.target.value})}} type="search" placeholder="Search Blood Group" aria-label="Search" value = {this.state.Search}/>
                        </form>
                    </div>
                    <br/><br/>
                    <div class="table">
                        <table class="table table-striped table-dark">
                            <thead>
                                <tr>
                                    <th scope="row">ROLL NUMBER</th>
                                    <th scope="col">BRANCH</th>
                                    <th scope="col">BLOOD GROUP</th>
                                    <th scope="col">DETAILS</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.Loading?(
                                        <h4>Loading...</h4>
                                    ):(
                                        this.state.data.filter((value)=>{
                                            if (this.state.Search === "") {
                                                return value;
                                            }else if (value.BloodGroup.toLowerCase().includes(this.state.Search.toLowerCase())) {
                                                
                                                return value;
                                            }
                                        }).map((item)=>{
                                            
                                            return(
                                            <tr key = {item._id} >
                                                
                                                <th scope="row">{item.RollNo.toUpperCase()}</th>
                                                <td>{item.Branch.toUpperCase()}</td>
                                                <td>{item.BloodGroup.toUpperCase()}</td>
                                                <td>
                                                    <Link to={`view/:_id=${item._id}`}>
                                                        <button type="button" className="btn btn-primary btn-sm">View</button>
                                                    </Link>
                                                </td>
                                                
                                            </tr>
                                            )
                                        }) 
                                    )
                                }
                                
                 
                            </tbody>    
                        </table>
                    </div>
                </div>
            </div>
            
            </>
            
        )
    }
}
