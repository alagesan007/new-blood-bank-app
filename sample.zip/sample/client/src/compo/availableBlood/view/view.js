import React, { Component,} from 'react'
import axios from "axios";
import './view.css';
import emailjs from 'emailjs-com';
import { Link } from "react-router-dom";

export default class View extends Component {
    constructor(){
        super();
        this.state = {
            id:"",
            data:{},
            value:{},
            homeBut:false
            
        }
    }
    

    componentDidMount(){
        this.getAll();
        const pathname = window.location.pathname;
        this.setState({id:pathname.slice(26)})
        
        
    }
    getAll(){
        axios.get("https://excel-blood-bank-management-system.onrender.com/get")
        .then(res => {

            res.data.filter(val=>{
                if (val._id === this.state.id) {
                    this.setState({value:val})
                }
            })        
            
        })
        .catch(err => {
            console.error(err); 
        })
    }
    sendEmail(e){
        e.preventDefault();
        emailjs.sendForm('service_xxpaa77', 'template_zu9543g',e.target, 'oQ0kLXJVQYXpImDQB')
        .then((result) => {
            console.log(result.text);
            alert("your mail was send successfully.")
            
        }, (error) => {
            console.log(error.text);
        });
        e.target.reset();
    }
    render() {
        return (
            <div className="MainView">
                <div className="innerView">
                    <div className="details">
                        <div className="header">
                            
                            <h1><img src="https://img.icons8.com/office/2x/user.png" alt="icon"/>{this.state.value.RollNo}</h1>
                        </div>
                        <br/>
                        <div className="contend">
                            <h4>Donor Details</h4><br/>
                            <h5>Age : {this.state.value.Age}</h5>
                            <h5>Blood Group : {this.state.value.BloodGroup}</h5>
                            <h5>Department : {this.state.value.Dep}</h5>
                            <h5>Branch : {this.state.value.Branch}</h5>
                            <h5>Email : <small>{this.state.value.Email}</small></h5>
                        </div>
                        <hr/>
                        <h5>Send Mail To Request Blood</h5>
                        <br/>
                        <form onSubmit={this.sendEmail}>
                            <label><b>Donor Id</b></label><br/>
                            <input type="text" name="donor" value={this.state.value.RollNo}/>
                            <br/>
                            <label><b>Your Name</b></label><br/>
                            <input required type="text" name="from_name" />
                            <br/>
                            <label><b>Mail To</b></label><br/>
                            <input type="text" name="To_Email" value= {this.state.value.Email} />
                            <br/>
                            <label><b>Blood Group</b></label><br/>
                            <input required type="text" name="blood_group" value={this.state.value.BloodGroup} />
                            <br/>
                            <label><b>Hospital Name</b></label><br/>
                            <input type="text" name="hospital_name" />
                            <br/>
                            <label><b>City</b></label><br/>
                            <input required type="text" name="city" />
                            <br/>
                            <label><b>Contact Number</b></label><br/>
                            <input required type="text" name="contact" />
                            <br/><br/>
                            
                            <input  className="btn btn-success" type="submit" value="Send" />
                            <div class="homeBut">
                            {
                                this.state.homeBut === true?(
                                    <Link>
                                        <input className="btn btn-success" type="submit" value="Home" />
                                    </Link>
                                ):(<p></p> )
                            }
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        )
    }
}




