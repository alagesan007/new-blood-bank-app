import React, { Component } from 'react';
import { Link } from "react-router-dom";
import axios from 'axios';
import './register.css';

export default class Register extends Component {
    constructor(){
        super();

        this.state={
            RollNo : "",
            Age : "",
            BloodGroup:"",
            Email:"",
            Branch:"",
            Dep:"",
            Str: "",
            BkHome:false
            
           
        }
    }

    infoSubmit = (event)=>{
        event.preventDefault();
        const data = {
            RollNo:this.state.RollNo,
            Age:this.state.Age,
            BloodGroup:this.state.BloodGroup,
            Email:this.state.Email,
            Branch:this.state.Branch,
            Dep:this.state.Dep
            
        }
        console.log(data);
        
        const url = "https://excel-blood-bank-management-system.onrender.com/";
        axios.post(url,data)
        .then(res => {
            console.log(res)
            this.setState({Str:"Submitted Succesfully...Back To Home"})
            this.setState({BkHome:true});
        })
        .catch(err => {
            console.error(err); 
        })
    }
    render() {
        return (
            <div className="block">
                
                <div className="innerBlock">
                <h3>Donate Blood</h3> 
                <br/>
                <h5 className="msg" >{this.state.Str}</h5>
                <form onSubmit = {this.infoSubmit} autoComplete = "off">
                    <div class="input1">
                        <div class="field">
                            <label for="exampleInputEmail1">Roll Number</label>
                            <input type="text" required
                                className="form-control"
                                id="exampleInputEmail1"
                                placeholder="Roll Number"
                                onChange={(e)=>this.setState({RollNo:e.target.value})}
                                name= "Name"
                                value = {this.state.RollNo}
                            />
                            
                        </div>
                        <br/>
                        <div class="field"> 
                            <label for="exampleInputAge">Age</label>
                            <input type="number" required
                                className="form-control"
                                id="exampleInputAge"
                                placeholder="Age" 
                                onChange={(e)=>this.setState({Age:e.target.value})}
                                name= "Age"  
                                value = {this.state.Age}
                            />
                        </div>
                        <br/>
                        <div class="field">
                            <label for="exampleInputBlood">Blood Group</label>    
                            <input type="text" required
                                className="form-control"
                                id="exampleInputBlood"
                                placeholder="BloodGroup" 
                                onChange={(e)=>this.setState({BloodGroup:e.target.value})}
                                name= "BloodGroup"  
                                value = {this.state.BloodGroup}
                            />
                        </div>
                        <br/>
                        <div class="field">
                            <label for="exampleInputContact">Email Id</label>    
                            <input type="email" required
                                className="form-control"
                                id="exampleInputContact"
                                placeholder="Email Id" 
                                onChange={(e)=>this.setState({Email:e.target.value})}
                                name= "Email"  
                                value = {this.state.Email}
                            />
                        </div>
                        <br/>
                        <div class="field">
                            <label for="exampleInputPassword1">Degree</label>
                            <input type="text" required
                                className="form-control"
                                id="exampleInputPassword1"
                                placeholder="Degree" 
                                onChange={(e)=>this.setState({Branch:e.target.value})}
                                name= "Dep"  
                                value = {this.state.Branch}
                            />
                        </div>
                        <br/>
                        <div class="field">
                            <label for="exampleInputPassword1">Department</label>    
                            <input type="text" required
                                className="form-control"
                                id="exampleInputPassword1"
                                placeholder="Department Name" 
                                onChange={(e)=>this.setState({Dep:e.target.value})}
                                name= "Dep"  
                                value = {this.state.Dep}
                            />
                        </div>
                        <br/>
                        
                            <div class="field2">
                                   
                                <input className="checkBox" type="checkbox" id="vehicle1" name="vehicle1" value="Bike"/>
                                <label>I agree to donate blood</label> 
                            </div>
                        
                    </div>
                    <br/>
                    <div class="setOfButtons">
                    <div className="buttonREG">
                        <button type="submit"  className="btn btn-success btn-sm">Submit</button>
                    </div>
                    <div>
                    {
                        this.state.BkHome == true ? (
                            <Link to ="/">
                            <button type="submit"  className="btn btn-secondary btn-sm">Home</button>
                            </Link>
                        ):(<h1></h1>)
                    }
                    </div>
                    </div>
                    
                    
                    
</form>
                </div>
            </div>
        )
    }
}

