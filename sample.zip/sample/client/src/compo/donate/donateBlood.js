import React, { Component } from 'react'
import { Link } from "react-router-dom";
import './donate.css';




export default class DonateBlood extends Component {
    constructor(){
        super();

        this.state={
            Weight : "",
            Height : "",
            Str:"",
            Val:false
           
        }
    }
    
    infoSubmit = event =>{
        event.preventDefault();
        if (this.state.Weight === "" || this.state.Height === "") {
            this.setState({Str:"please enter the field..."})
        }
        if (parseInt(this.state.Weight) < 50) {
            this.setState({Str:"your weight is under 50kg,so you not eligible to donate blood"})
        }else if (true) {
            var bmi;
            var weight = parseInt(this.state.Weight)
            var height = parseInt(this.state.Height)
            bmi = (weight / Math.pow( (height/100), 2 )).toFixed(1);
            
            if (18.5 < bmi && 24.9 > bmi) {
                this.setState({Str:`Your BMI is - ${bmi}%, your HEALTHY - click donate...`})
            }
            else if (bmi < 18.5) {
                this.setState({Str:`Your BMI is - ${bmi}%, your UNDER WEIGHT - click donate...`})
            }
            else if (bmi < 29.9 && bmi > 25.0) {
                this.setState({Str:`Your BMI is - ${bmi}%, your OVER WEIGHT - click donate...`})
            }else if (bmi > 30.0) {
                this.setState({Str:`Your BMI is - ${bmi}%, your OBESE - click donate...`})
            }
        }
        this.setState({Val:true})
        
    }
    render() {
        return (
            <div className="container">

              
              <div className="main">
              <h3>Check your BMI</h3>
              
              <form  autoComplete = "off">

                    <div class="inputs"><div class="field1">
                        <h6>{this.state.Str}</h6>

                        <br/>
                        <br/>
                        <label for="exampleInputEmail1">Weight</label>    
                        <input type="text"
                            className="form-control"
                            id="exampleInputEmail1"
                            placeholder="in kg"
                            onChange={(e)=>this.setState({Weight:e.target.value})}
                            name= "Weight"
                            value = {this.state.Weight}
                        />
                        
                    </div>
                    <br/>
                    <div class="field1">
                        <label for="exampleInputEmail1">Height</label>
                        <input type="text"
                            className="form-control"
                            id="exampleInputEmail1"
                            placeholder="in cm" 
                            onChange={(e)=>this.setState({Height:e.target.value})}
                            name= "Height"
                            value = {this.state.Height}
                        />
                    </div></div>
                    <br/>
                    <div class="buttons">
                        <div className="button">
                            <button  onClick={this.infoSubmit}  className="btn btn-success btn-sm">Check</button>
                        </div> 
                        
                        <div className="button">
                            {parseInt(this.state.Weight) >= 50 && this.state.Val === true ?(
                                    <Link to="register">
                                <button  type="submit "  className="btn btn-success btn-sm">Donate</button></Link>):(<p></p>)}
                            </div>
                        
                    </div>
                </form>
              </div>
            </div>
        )
    }
}
