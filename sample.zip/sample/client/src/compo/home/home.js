import React from 'react'
import Navbar from "../navbar/navbar.js";
import "./home.css"
import Cards from './cards/cards.js'
import Footer from '../footer/footer.js'
import { Link } from "react-router-dom";
import MiniNav from './miniNav.js'

export default function Home() {
    return (
        <div className="homeContainer">
            <Navbar/>
            <MiniNav/>
            
            <Cards/>
            <hr/>
            <h2>Five Reasons Why You Should Donate Blood</h2>
            <br/>
            <ol className="content">
                <li>Development of new red blood cells
                    Within the first 48 hours of blood donation, the donor's body starts replenishing the lost red blood cells.</li>
                <li>Reducing risk of heart disease
                    As per several studies and reports, when there is a rise in the iron level in blood, it raises the chances of heart diseases.</li>
                <li>Burns calories
                    Donating blood can burn approximately 650 calories for each pint that is like 450 ml of blood.</li>
                <li>Free blood test
                    On donating blood, the donor receives a free mini health screening and blood tests.</li>
                <li>The minimum time advised between two donations is 3         months.     This gap helps blood regain the normal haemoglobin count.

                </li>
            </ol>
            <hr/>
            <h2>Donor And Reciever Combination</h2>
            <br/>
            <div class="tableDiv">
            <table class="table table-striped table-dark">
                <thead>
                    <tr>
                        <th scope="col">S No</th>
                        <th scope="col">Recipient Blood Type</th>
                        <th scope="col">Matching Donor Blood Type</th>
      
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                            <td>A+</td>
                            <td>A+, A-, O+, O-</td>
      
                    </tr>
                    <tr>
                        <th scope="row">2</th>
                        <td>A-</td>
                        <td>A-, O-</td>
                    </tr>
                    <tr>
                        <th scope="row">3</th>
                        <td>B+</td>
                        <td>B+, B-, O+, O-</td>
                    </tr>
                    <tr>
                        <th scope="row">4</th>
                        <td>B-</td>
                        <td>B-, O-</td>
                    </tr>
                    <tr>
                        <th scope="row">5</th>
                        <td>AB+</td>
                        <td>Compatible With All Blood Types</td>
                    </tr>
                    <tr>
                        <th scope="row">6</th>
                        <td>AB-</td>
                        <td>A-, B-, O-, AB-</td>
                    </tr>
                    <tr>
                        <th scope="row">7</th>
                        <td>O+</td>
                        <td>O+, O-</td>
                    </tr>
                    <tr>
                        <th scope="row">8</th>
                        <td>O-</td>
                        <td>O-</td>
                    </tr>
    
                </tbody>
            </table>
            </div>
            <hr/>
            

            <h2>Availability Of Blood In Excel Group Institutions</h2>
            <p>click here...   
                <Link to="availableBlood">
                    <button className="btn btn-sm btn-success">Available Blood</button>
                </Link>
            </p>
            <Footer/>
        </div>
    )
}
