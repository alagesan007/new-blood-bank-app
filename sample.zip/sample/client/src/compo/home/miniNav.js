import React from 'react'
import './home.css'

export default function MiniNav() {
    return (
        <div className="miniNav">
            <button className="btn btn-sm btn-danger" ><a  target="_blank" href="https://erode.nic.in/public-utility/government-hospital-erode/">Government_Hospital_Erode
                </a></button>
            
            
            <button className="btn btn-sm btn-danger"><a  target="_blank" href="https://www.medindia.net/directories/blood-bank-services/sri-saanthi-blood-bank-run-by-kaveri-trust-erode-5192.htm">Sri_Saanthi_Blood_Bank</a></button>

            <button className="btn btn-sm btn-danger"><a  target="_blank" href="https://tamilnadu-voluntary-blood-bank-and-research-centre.business.site/">Tamilnadu_Voluntary_Blood_Bank</a></button>
            <button className="btn btn-sm btn-danger"><a  target="_blank" href="https://www.medindia.net/directories/blood-bank-services/lotus-blood-bank-erode-5187.htm">Lotus_Blood_Bank</a></button>
            <button className="btn btn-sm btn-danger"><a  target="_blank" href="https://www.medindia.net/directories/blood-bank-services/kongu-blood-bank-erode-5186.htm">Kongu_Blood_Bank</a></button>
            <button className="btn btn-sm btn-danger"><a target="_blank" href="https://vivekanandha.hospital/">Vivekanandha_Hospital</a></button>

        </div>
    )
}
