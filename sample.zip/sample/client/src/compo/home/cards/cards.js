import React from 'react'
import './cards.css'

export default function Cards() {
    return (
        <div className="row" >
            <div id="card" className="col-4" style={{width:"18rem"}}>
            <img className="card-img-top" src="https://cdn.pixabay.com/photo/2021/04/22/19/59/blood-sample-6200016__480.jpg" alt="Card image cap"/>
                <div className="card-body">
                    <h4>Important Things To Know Before Donate:</h4>
                    <ul>
                        <li>You need to be 17 or older to donate whole blood</li>
                        <li>You have to weigh at least 50kg</li>
                        <li>Be in good health to donate</li>
                        <li>You must wait at least 8 weeks between whole blood donations </li>
                    </ul>
                </div>
            </div>
            <div id="card" className="col-4" style={{width:"18rem"}}>
                <img className="card-img-top" src="https://cdn.pixabay.com/photo/2019/04/24/09/38/blood-donation-4151721__480.jpg" alt="Card image cap"/>
                    <div className="card-body">
                    <h4>Benifits Of Giving Blood:</h4>
                        <ul>
                            <li>Reduce stress</li>
                            <li>Improve your emotional well-being</li>
                            <li>Benefit your physical health</li>
                            <li>Help get rid of negative feelings</li>
                            <li>can help your liver stay healthy</li>
                        </ul>
                    </div>
            </div>
            <div id="card" className="col-4" style={{width:"18rem"}}>
                <img className="card-img-top" src="https://cdn.pixabay.com/photo/2019/04/29/16/56/blood-donation-4166552__340.jpg" alt="Card image cap"/>
                <div className="card-body">
                    <h4>Suggestions For Donating Blood:</h4>
                    <ul>
                        <li>Drink an extra 16 ounces of water before your appointment.</li>
                        <li>Eat a healthy meal that’s low in fat.</li>
                        <li>Wear a short-sleeved shirt or a shirt with sleeves that are easy to roll up.</li>
                    </ul>
                </div>
            </div>    
        </div>
    )
}
