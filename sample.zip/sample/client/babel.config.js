module.exports = {
    presets: [
      [
        '@babel/preset-env',
        {
          targets: {
            node: 'current', // or specify your target environments
          },
        },
      ],
      '@babel/preset-react', // Add this line to enable transformation of JSX syntax
    ],
    plugins: [
      '@babel/plugin-proposal-optional-chaining', // Add other plugins you may need
    ],
  };
  